// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "ximg_pipeline.h"

extern XImg_pipeline_Config XImg_pipeline_ConfigTable[];

XImg_pipeline_Config *XImg_pipeline_LookupConfig(u16 DeviceId) {
	XImg_pipeline_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XIMG_PIPELINE_NUM_INSTANCES; Index++) {
		if (XImg_pipeline_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XImg_pipeline_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XImg_pipeline_Initialize(XImg_pipeline *InstancePtr, u16 DeviceId) {
	XImg_pipeline_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XImg_pipeline_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XImg_pipeline_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

